<?php
/**
 * Footer template
 */
$footer_copyright_text = get_theme_mod( 'construction_footer_copyright_text', __( 'All rights reserved.', 'construction-theme' ) );
$show_footer_social    = get_theme_mod( 'construction_footer_show_social', true );
$footer_social_profiles = array(
    'facebook'  => array( 'label' => __( 'Facebook', 'construction-theme' ), 'icon' => 'fab fa-facebook-f' ),
    'instagram' => array( 'label' => __( 'Instagram', 'construction-theme' ), 'icon' => 'fab fa-instagram' ),
);
?>
<footer class="site-footer">
    <div class="container footer-widgets">
        <div class="footer-widget footer-company">
            <a class="footer-site-name" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
            <?php $site_description = get_bloginfo( 'description', 'display' ); ?>
            <?php if ( $site_description ) : ?>
                <p><?php echo esc_html( $site_description ); ?></p>
            <?php endif; ?>
        </div>
        <?php if ( get_theme_mod( 'construction_footer_show_quick_links', true ) ) : ?>
        <div class="footer-widget">
            <h4><?php echo esc_html( get_theme_mod( 'construction_footer_quick_links_heading', __( 'Quick Links', 'construction-theme' ) ) ); ?></h4>
            <nav aria-label="<?php esc_attr_e( 'Footer navigation', 'construction-theme' ); ?>">
                <?php if ( has_nav_menu( 'footer' ) ) : ?>
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'footer',
                        'menu_class'     => 'footer-menu',
                        'container'      => false,
                        'depth'          => 1,
                    ) );
                    ?>
                <?php else : ?>
                    <ul class="footer-menu">
                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'construction-theme' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Services', 'construction-theme' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/#about-us' ) ); ?>"><?php esc_html_e( 'About Us', 'construction-theme' ); ?></a></li>
                        <li><a href="<?php echo esc_url( home_url( '/#enquiry-section' ) ); ?>"><?php esc_html_e( 'Contact', 'construction-theme' ); ?></a></li>
                    </ul>
                <?php endif; ?>
            </nav>
        </div>
        <?php endif; ?>
        <?php if ( get_theme_mod( 'construction_footer_show_contact', true ) ) : ?>
        <div class="footer-widget">
            <h4><?php echo esc_html( get_theme_mod( 'construction_footer_contact_heading', __( 'Contact', 'construction-theme' ) ) ); ?></h4>
            <?php
            $contact_address = trim( (string) get_theme_mod( 'construction_contact_address', '' ) );
            $contact_phone   = trim( (string) get_theme_mod( 'construction_contact_phone', '' ) );
            $contact_email   = sanitize_email( (string) get_theme_mod( 'construction_contact_email', '' ) );
            $contact_tel     = preg_replace( '/[^0-9+]/', '', $contact_phone );
            ?>
            <address class="footer-contact">
                <?php if ( $contact_address ) : ?>
                    <p class="footer-contact-item">
                        <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                        <span><?php echo esc_html( $contact_address ); ?></span>
                    </p>
                <?php endif; ?>
                <?php if ( $contact_phone ) : ?>
                    <p class="footer-contact-item">
                        <i class="fas fa-phone-alt" aria-hidden="true"></i>
                        <?php if ( $contact_tel ) : ?>
                            <a href="<?php echo esc_url( 'tel:' . $contact_tel ); ?>"><?php echo esc_html( $contact_phone ); ?></a>
                        <?php else : ?>
                            <span><?php echo esc_html( $contact_phone ); ?></span>
                        <?php endif; ?>
                    </p>
                <?php endif; ?>
                <?php if ( $contact_email ) : ?>
                    <p class="footer-contact-item">
                        <i class="fas fa-envelope" aria-hidden="true"></i>
                        <a href="<?php echo esc_url( 'mailto:' . $contact_email ); ?>"><?php echo esc_html( $contact_email ); ?></a>
                    </p>
                <?php endif; ?>
            </address>
        </div>
        <?php endif; ?>
        <?php if ( $show_footer_social ) : ?>
        <div class="footer-widget footer-social">
            <h4><?php esc_html_e( 'Follow us', 'construction-theme' ); ?></h4>
            <ul class="footer-social-links" aria-label="<?php esc_attr_e( 'Social media', 'construction-theme' ); ?>">
                <?php foreach ( $footer_social_profiles as $key => $profile ) : ?>
                    <?php $social_url = get_theme_mod( "construction_footer_$key", '' ); ?>
                    <li>
                        <?php if ( $social_url ) : ?>
                            <a href="<?php echo esc_url( $social_url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $profile['label'] ); ?>">
                                <i class="<?php echo esc_attr( $profile['icon'] ); ?>" aria-hidden="true"></i>
                            </a>
                        <?php else : ?>
                            <span class="footer-social-icon" role="img" aria-label="<?php echo esc_attr( $profile['label'] ); ?>">
                                <i class="<?php echo esc_attr( $profile['icon'] ); ?>" aria-hidden="true"></i>
                            </span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
    <div class="container footer-bottom">
        <p>
            &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?><?php if ( $footer_copyright_text ) : ?>. <?php echo esc_html( $footer_copyright_text ); ?><?php endif; ?>
            <span class="footer-credit"> | <?php esc_html_e( 'Developed by', 'construction-theme' ); ?> <a href="https://chrisweb.in" target="_blank" rel="noopener noreferrer">chrisweb.in</a></span>
        </p>
    </div>
</footer>
<?php
$business_phone   = trim( (string) get_theme_mod( 'construction_contact_phone', '' ) );
$whatsapp_number  = trim( (string) get_theme_mod( 'construction_contact_whatsapp', '' ) );
$whatsapp_number  = $whatsapp_number ? $whatsapp_number : $business_phone;
$call_number      = preg_replace( '/[^0-9+]/', '', $business_phone );
$whatsapp_digits  = preg_replace( '/[^0-9]/', '', $whatsapp_number );
$show_whatsapp    = get_theme_mod( 'construction_footer_show_whatsapp_button', true );
$show_call        = get_theme_mod( 'construction_footer_show_call_button', true );
$whatsapp_label   = get_theme_mod( 'construction_footer_whatsapp_label', __( 'WhatsApp', 'construction-theme' ) );
$call_label       = get_theme_mod( 'construction_footer_call_label', __( 'Call Now', 'construction-theme' ) );
?>
<?php if ( $show_whatsapp || $show_call ) : ?>
<div class="floating-contact" role="group" aria-label="<?php esc_attr_e( 'Contact us', 'construction-theme' ); ?>">
    <?php if ( $show_whatsapp ) : ?>
        <a class="floating-contact-button floating-contact-whatsapp" href="<?php echo $whatsapp_digits ? esc_url( 'https://wa.me/' . $whatsapp_digits ) : esc_url( home_url( '/#enquiry-section' ) ); ?>" <?php echo $whatsapp_digits ? 'target="_blank" rel="noopener noreferrer"' : 'title="' . esc_attr__( 'Set a WhatsApp number in Appearance → Customize → Contact Details to enable chat.', 'construction-theme' ) . '"'; ?> aria-label="<?php echo $whatsapp_digits ? esc_attr__( 'Chat with us on WhatsApp', 'construction-theme' ) : esc_attr__( 'WhatsApp number not set; go to the enquiry form', 'construction-theme' ); ?>">
            <i class="fab fa-whatsapp" aria-hidden="true"></i>
            <span><?php echo esc_html( $whatsapp_label ); ?></span>
        </a>
    <?php endif; ?>
    <?php if ( $show_call ) : ?>
        <a class="floating-contact-button floating-contact-call" href="<?php echo $call_number ? esc_url( 'tel:' . $call_number ) : esc_url( home_url( '/#enquiry-section' ) ); ?>" <?php echo $call_number ? '' : 'title="' . esc_attr__( 'Set a business phone in Appearance → Customize → Contact Details to enable calling.', 'construction-theme' ) . '"'; ?> aria-label="<?php echo $call_number ? esc_attr( sprintf( __( 'Call us at %s', 'construction-theme' ), $business_phone ) ) : esc_attr__( 'Business phone not set; go to the enquiry form', 'construction-theme' ); ?>">
            <i class="fas fa-phone" aria-hidden="true"></i>
            <span><?php echo esc_html( $call_label ); ?></span>
        </a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
