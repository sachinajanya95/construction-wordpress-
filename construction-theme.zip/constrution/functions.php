<?php
/**
 * Theme functions and definitions
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Theme setup
function construction_theme_setup() {
    // Add support for title tag, post thumbnails, custom logo, and automatic feed links.
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', array(
        'height'      => 80,
        'width'       => 250,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_theme_support( 'elementor' );

    // Register navigation menus.
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'construction-theme' ),
        'footer'  => esc_html__( 'Footer Menu', 'construction-theme' ),
    ) );
}
add_action( 'after_setup_theme', 'construction_theme_setup' );

function construction_primary_menu_fallback() {
    $items = array(
        'hero-slider'     => __( 'Home', 'construction-theme' ),
        'about-us'        => __( 'About', 'construction-theme' ),
        'services'        => __( 'Services', 'construction-theme' ),
        'gallery'         => __( 'Projects', 'construction-theme' ),
        'enquiry-section' => __( 'Contact', 'construction-theme' ),
    );
    ?>
    <nav class="main-navigation" aria-label="<?php esc_attr_e( 'Primary menu', 'construction-theme' ); ?>">
        <ul id="primary-menu" class="menu">
            <?php foreach ( $items as $anchor => $label ) : ?>
                <li class="menu-item">
                    <a href="<?php echo esc_url( 'services' === $anchor ? home_url( '/services/' ) : home_url( '/#' . $anchor ) ); ?>"><?php echo esc_html( $label ); ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </nav>
    <?php
}

function construction_primary_menu_services_page( $items, $args ) {
    if ( empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
        return $items;
    }

    foreach ( $items as $item ) {
        $path = wp_parse_url( $item->url, PHP_URL_PATH );
        $title = sanitize_title( $item->title );
        $is_services_link = in_array( $title, array( 'service', 'services', 'our-service', 'our-services' ), true )
            || ( is_string( $path ) && preg_match( '#/services/?$#', $path ) )
            || ( is_string( $item->url ) && preg_match( '/#services$/', $item->url ) );

        if ( $is_services_link ) {
            $item->url = home_url( '/services/' );
        }
    }

    return $items;
}
add_filter( 'wp_nav_menu_objects', 'construction_primary_menu_services_page', 10, 2 );

function construction_ensure_services_page() {
    if ( get_page_by_path( 'services', OBJECT, 'page' ) ) {
        return;
    }

    $page_id = wp_insert_post(
        array(
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'post_title'     => __( 'Services', 'construction-theme' ),
            'post_name'      => 'services',
            'post_content'   => '',
            'comment_status' => 'closed',
        ),
        true
    );

    if ( is_wp_error( $page_id ) ) {
        error_log( 'Construction Theme could not create the Services page: ' . $page_id->get_error_message() );
    }
}
add_action( 'init', 'construction_ensure_services_page', 20 );

// Enqueue styles and scripts
function construction_theme_assets() {
    $theme_version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'construction-theme-main', get_stylesheet_uri(), array(), $theme_version );
    // Theme JavaScript
    wp_enqueue_script( 'construction-theme-main-js', get_template_directory_uri() . '/assets/js/theme.js', array('jquery'), $theme_version, true );
    // Localize script for AJAX URL and nonces.
    wp_localize_script( 'construction-theme-main-js', 'constructionTheme', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'construction_theme_nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'construction_theme_assets' );

function construction_default_service_descriptions() {
    return array(
        'construction_plan'    => __( 'Planning and coordination for a smooth, well-managed construction journey.', 'construction-theme' ),
        'project_execution'    => __( 'End-to-end project execution with skilled teams, clear coordination, and quality checks throughout construction.', 'construction-theme' ),
        'design_surveying'     => __( 'Precise surveying and measurement to support design decisions and build accuracy.', 'construction-theme' ),
        'interior_design'      => __( 'Thoughtful interior spaces and finishes that balance function, comfort, and style.', 'construction-theme' ),
        'landscaping_services' => __( 'Outdoor design and finishing that enhances curb appeal, usability, and comfort.', 'construction-theme' ),
        'plan_estimation'      => __( 'Budgeting and estimating support to help keep your project realistic and well informed.', 'construction-theme' ),
    );
}

// Register custom post type for Projects
function construction_register_project_cpt() {
    $labels = array(
        'name'               => _x( 'Projects', 'post type general name', 'construction-theme' ),
        'singular_name'      => _x( 'Project', 'post type singular name', 'construction-theme' ),
        'menu_name'          => _x( 'Projects', 'admin menu', 'construction-theme' ),
        'name_admin_bar'     => _x( 'Project', 'add new on admin bar', 'construction-theme' ),
        'add_new'            => _x( 'Add New', 'project', 'construction-theme' ),
        'add_new_item'       => __( 'Add New Project', 'construction-theme' ),
        'new_item'           => __( 'New Project', 'construction-theme' ),
        'edit_item'          => __( 'Edit Project', 'construction-theme' ),
        'view_item'          => __( 'View Project', 'construction-theme' ),
        'all_items'          => __( 'All Projects', 'construction-theme' ),
        'search_items'       => __( 'Search Projects', 'construction-theme' ),
        'parent_item_colon'  => __( 'Parent Projects:', 'construction-theme' ),
        'not_found'          => __( 'No projects found.', 'construction-theme' ),
        'not_found_in_trash' => __( 'No projects found in Trash.', 'construction-theme' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'project' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'taxonomies'         => array( 'category' ), // Use category to separate residential/commercial.
    );

    register_post_type( 'project', $args );
}
add_action( 'init', 'construction_register_project_cpt' );

// Register Customizer settings for site-wide editable content
function construction_theme_customizer_register( $wp_customize ) {
    $wp_customize->add_section( 'construction_header_section', array(
        'title'    => __( 'Header & Navigation', 'construction-theme' ),
        'priority' => 25,
    ) );

    $wp_customize->add_setting( 'construction_header_cta_label', array(
        'default'           => __( 'Enquiry Now', 'construction-theme' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'construction_header_cta_label_control', array(
        'label'    => __( 'Header Button Text', 'construction-theme' ),
        'section'  => 'construction_header_section',
        'settings' => 'construction_header_cta_label',
        'type'     => 'text',
    ) );

    $wp_customize->add_setting( 'construction_header_cta_url', array(
        'default'           => home_url( '/#enquiry-section' ),
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( 'construction_header_cta_url_control', array(
        'label'       => __( 'Header Button Link', 'construction-theme' ),
        'description' => __( 'Enter a page URL or section link such as #enquiry-section.', 'construction-theme' ),
        'section'     => 'construction_header_section',
        'settings'    => 'construction_header_cta_url',
        'type'        => 'text',
    ) );

    // Hero Slider Section
    $wp_customize->add_section( 'construction_hero_section', array(
        'title'    => __( 'Hero Slider', 'construction-theme' ),
        'priority' => 30,
    ) );

    // Number of slides (fixed to 3 for demo). Create settings for each.
    for ( $i = 1; $i <= 3; $i++ ) {
        $wp_customize->add_setting( "construction_hero_image_$i", array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, "construction_hero_image_{$i}_control", array(
            'label'    => sprintf( __( 'Slide %d Image', 'construction-theme' ), $i ),
            'section'  => 'construction_hero_section',
            'settings' => "construction_hero_image_$i",
        ) ) );

        $wp_customize->add_setting( "construction_hero_heading_$i", array(
            'default'           => __( 'Welcome to Our Construction Company', 'construction-theme' ),
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( "construction_hero_heading_{$i}_control", array(
            'label'   => sprintf( __( 'Slide %d Heading', 'construction-theme' ), $i ),
            'section' => 'construction_hero_section',
            'settings' => "construction_hero_heading_$i",
            'type'    => 'text',
        ) );

        $wp_customize->add_setting( "construction_hero_subtitle_$i", array(
            'default'           => __( 'Building Dreams Into Reality', 'construction-theme' ),
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( "construction_hero_subtitle_{$i}_control", array(
            'label'   => sprintf( __( 'Slide %d Subtitle', 'construction-theme' ), $i ),
            'section' => 'construction_hero_section',
            'settings' => "construction_hero_subtitle_$i",
            'type'    => 'text',
        ) );
    }

    $wp_customize->add_setting( 'construction_hero_button_label', array(
        'default'           => __( 'Discover More', 'construction-theme' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'construction_hero_button_label_control', array(
        'label'    => __( 'Banner Button Text', 'construction-theme' ),
        'section'  => 'construction_hero_section',
        'settings' => 'construction_hero_button_label',
        'type'     => 'text',
    ) );

    $wp_customize->add_setting( 'construction_hero_button_url', array(
        'default'           => '#about-us',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( 'construction_hero_button_url_control', array(
        'label'       => __( 'Banner Button Link', 'construction-theme' ),
        'description' => __( 'Enter a page URL or section link such as #about-us.', 'construction-theme' ),
        'section'     => 'construction_hero_section',
        'settings'    => 'construction_hero_button_url',
        'type'        => 'text',
    ) );

    $wp_customize->add_setting( 'construction_hero_alignment', array(
        'default'           => 'center',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'construction_hero_alignment_control', array(
        'label'    => __( 'Banner Text Alignment', 'construction-theme' ),
        'section'  => 'construction_hero_section',
        'settings' => 'construction_hero_alignment',
        'type'     => 'select',
        'choices'  => array(
            'center' => __( 'Centered', 'construction-theme' ),
            'left'   => __( 'Left aligned', 'construction-theme' ),
        ),
    ) );

    $wp_customize->add_setting( 'construction_hero_height', array(
        'default'           => 'standard',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'construction_hero_height_control', array(
        'label'    => __( 'Banner Height', 'construction-theme' ),
        'section'  => 'construction_hero_section',
        'settings' => 'construction_hero_height',
        'type'     => 'select',
        'choices'  => array(
            'compact'  => __( 'Compact', 'construction-theme' ),
            'standard' => __( 'Standard', 'construction-theme' ),
            'tall'     => __( 'Tall', 'construction-theme' ),
        ),
    ) );

    $wp_customize->add_setting( 'construction_hero_image_position', array(
        'default'           => 'center',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'construction_hero_image_position_control', array(
        'label'    => __( 'Banner Image Focus', 'construction-theme' ),
        'section'  => 'construction_hero_section',
        'settings' => 'construction_hero_image_position',
        'type'     => 'select',
        'choices'  => array(
            'center'        => __( 'Center', 'construction-theme' ),
            'top'           => __( 'Top', 'construction-theme' ),
            'bottom'        => __( 'Bottom', 'construction-theme' ),
            'left center'   => __( 'Left', 'construction-theme' ),
            'right center'  => __( 'Right', 'construction-theme' ),
        ),
    ) );

    // Services Section (editable via a repeater would need plugin; we provide three simple settings)
    $wp_customize->add_section( 'construction_services_section', array(
        'title'    => __( 'Services', 'construction-theme' ),
        'priority' => 40,
    ) );
    $services = array(
        'construction_plan' => __( 'Construction Plan', 'construction-theme' ),
        'project_execution' => __( 'Project Execution', 'construction-theme' ),
        'design_surveying' => __( 'Design Surveying', 'construction-theme' ),
        'interior_design' => __( 'Interior Design', 'construction-theme' ),
        'landscaping_services' => __( 'Landscaping Services', 'construction-theme' ),
        'plan_estimation' => __( 'Plan Estimation', 'construction-theme' ),
    );
    $service_descriptions = construction_default_service_descriptions();
    foreach ( $services as $key => $label ) {
        $wp_customize->add_setting( "construction_service_title_$key", array(
            'default'           => $label,
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( "construction_service_title_{$key}_control", array(
            'label'   => sprintf( __( 'Service: %s Title', 'construction-theme' ), $label ),
            'section' => 'construction_services_section',
            'settings' => "construction_service_title_$key",
            'type'    => 'text',
        ) );
        $wp_customize->add_setting( "construction_service_description_$key", array(
            'default'           => $service_descriptions[ $key ],
            'sanitize_callback' => 'sanitize_textarea_field',
        ) );
        $wp_customize->add_control( "construction_service_description_{$key}_control", array(
            'label'    => sprintf( __( 'Service: %s Description', 'construction-theme' ), $label ),
            'section'  => 'construction_services_section',
            'settings' => "construction_service_description_$key",
            'type'     => 'textarea',
        ) );
        $wp_customize->add_setting( "construction_service_icon_$key", array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, "construction_service_icon_{$key}_control", array(
            'label'    => sprintf( __( 'Service %s Icon', 'construction-theme' ), $label ),
            'section'  => 'construction_services_section',
            'settings' => "construction_service_icon_$key",
        ) ) );
    }

    // Statistics Section
    $wp_customize->add_section( 'construction_stats_section', array(
        'title'    => __( 'Statistics', 'construction-theme' ),
        'priority' => 50,
    ) );
    $stats = array(
        'projects_completed' => __( 'Projects Completed', 'construction-theme' ),
        'happy_customers'   => __( 'Happy Customers', 'construction-theme' ),
        'years_experience'  => __( 'Years in Business', 'construction-theme' ),
    );
    $sample_stats = array(
        'projects_completed' => 128,
        'happy_customers'    => 96,
        'years_experience'   => 12,
    );
    foreach ( $stats as $key => $label ) {
        $wp_customize->add_setting( "construction_stat_number_$key", array(
            'default'           => (string) $sample_stats[ $key ],
            'sanitize_callback' => 'absint',
        ) );
        $wp_customize->add_control( "construction_stat_number_{$key}_control", array(
            'label'   => $label,
            'section' => 'construction_stats_section',
            'settings' => "construction_stat_number_$key",
            'type'    => 'number',
        ) );
    }

    // Contact Section
    $wp_customize->add_section( 'construction_contact_section', array(
        'title'    => __( 'Contact Details', 'construction-theme' ),
        'priority' => 60,
    ) );
    $contact_fields = array(
        'address' => __( 'Address', 'construction-theme' ),
        'phone'   => __( 'Business Phone (include country code)', 'construction-theme' ),
        'email'   => __( 'Email', 'construction-theme' ),
        'whatsapp' => __( 'WhatsApp Business Number (optional; defaults to phone)', 'construction-theme' ),
    );
    foreach ( $contact_fields as $key => $label ) {
        $wp_customize->add_setting( "construction_contact_$key", array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( "construction_contact_{$key}_control", array(
            'label'   => $label,
            'section' => 'construction_contact_section',
            'settings' => "construction_contact_$key",
            'type'    => 'text',
        ) );
    }

    // Footer Content
    $wp_customize->add_section( 'construction_footer_section', array(
        'title'       => __( 'Footer Content', 'construction-theme' ),
        'description' => __( 'Edit footer headings, legal text, social links, and floating contact buttons. Company name and tagline are managed under Site Identity; footer contact details are managed under Contact Details; footer quick links can be assigned under Menus.', 'construction-theme' ),
        'priority'    => 65,
    ) );

    $footer_text_fields = array(
        'quick_links_heading' => array(
            'label'   => __( 'Quick Links Heading', 'construction-theme' ),
            'default' => __( 'Quick Links', 'construction-theme' ),
        ),
        'contact_heading' => array(
            'label'   => __( 'Contact Heading', 'construction-theme' ),
            'default' => __( 'Contact', 'construction-theme' ),
        ),
        'cta_heading' => array(
            'label'   => __( 'Enquiry Heading', 'construction-theme' ),
            'default' => __( 'Planning a project?', 'construction-theme' ),
        ),
        'cta_text' => array(
            'label'   => __( 'Enquiry Description', 'construction-theme' ),
            'default' => __( 'Tell us what you have in mind. We would be glad to help you take the next step.', 'construction-theme' ),
            'type'    => 'textarea',
        ),
        'cta_label' => array(
            'label'   => __( 'Enquiry Link Text', 'construction-theme' ),
            'default' => __( 'Start a conversation', 'construction-theme' ),
        ),
        'copyright_text' => array(
            'label'   => __( 'Copyright Notice', 'construction-theme' ),
            'default' => __( 'All rights reserved.', 'construction-theme' ),
        ),
    );
    foreach ( $footer_text_fields as $key => $field ) {
        $wp_customize->add_setting( "construction_footer_$key", array(
            'default'           => $field['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( "construction_footer_{$key}_control", array(
            'label'    => $field['label'],
            'section'  => 'construction_footer_section',
            'settings' => "construction_footer_$key",
            'type'     => isset( $field['type'] ) ? $field['type'] : 'text',
        ) );
    }

    $footer_toggles = array(
        'show_quick_links' => array(
            'label'   => __( 'Show Quick Links', 'construction-theme' ),
            'default' => true,
        ),
        'show_contact' => array(
            'label'   => __( 'Show Contact Details Section', 'construction-theme' ),
            'default' => true,
        ),
        'show_cta' => array(
            'label'   => __( 'Show Enquiry Call to Action', 'construction-theme' ),
            'default' => true,
        ),
        'show_social' => array(
            'label'   => __( 'Show Social Links', 'construction-theme' ),
            'default' => true,
        ),
        'show_whatsapp_button' => array(
            'label'   => __( 'Show Floating WhatsApp Button', 'construction-theme' ),
            'default' => true,
        ),
        'show_call_button' => array(
            'label'   => __( 'Show Floating Call Button', 'construction-theme' ),
            'default' => true,
        ),
    );
    foreach ( $footer_toggles as $key => $toggle ) {
        $wp_customize->add_setting( "construction_footer_$key", array(
            'default'           => $toggle['default'],
            'sanitize_callback' => 'wp_validate_boolean',
        ) );
        $wp_customize->add_control( "construction_footer_{$key}_control", array(
            'label'    => $toggle['label'],
            'section'  => 'construction_footer_section',
            'settings' => "construction_footer_$key",
            'type'     => 'checkbox',
        ) );
    }

    $floating_contact_labels = array(
        'whatsapp_label' => array(
            'label'   => __( 'Floating WhatsApp Button Text', 'construction-theme' ),
            'default' => __( 'WhatsApp', 'construction-theme' ),
        ),
        'call_label' => array(
            'label'   => __( 'Floating Call Button Text', 'construction-theme' ),
            'default' => __( 'Call Now', 'construction-theme' ),
        ),
    );
    foreach ( $floating_contact_labels as $key => $field ) {
        $wp_customize->add_setting( "construction_footer_$key", array(
            'default'           => $field['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( "construction_footer_{$key}_control", array(
            'label'    => $field['label'],
            'section'  => 'construction_footer_section',
            'settings' => "construction_footer_$key",
            'type'     => 'text',
        ) );
    }

    $wp_customize->add_setting( 'construction_footer_cta_url', array(
        'default'           => home_url( '/#enquiry-section' ),
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( 'construction_footer_cta_url_control', array(
        'label'       => __( 'Enquiry Link URL', 'construction-theme' ),
        'description' => __( 'Enter a page URL or section link such as #enquiry-section.', 'construction-theme' ),
        'section'     => 'construction_footer_section',
        'settings'    => 'construction_footer_cta_url',
        'type'        => 'url',
    ) );

    $social_profiles = array(
        'facebook'  => __( 'Facebook URL', 'construction-theme' ),
        'instagram' => __( 'Instagram URL', 'construction-theme' ),
    );
    foreach ( $social_profiles as $key => $label ) {
        $wp_customize->add_setting( "construction_footer_$key", array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ) );
        $wp_customize->add_control( "construction_footer_{$key}_control", array(
            'label'       => $label,
            'description' => __( 'Leave blank to hide this social link.', 'construction-theme' ),
            'section'     => 'construction_footer_section',
            'settings'    => "construction_footer_$key",
            'type'        => 'url',
        ) );
    }
}
add_action( 'customize_register', 'construction_theme_customizer_register' );

// Ajax handler for enquiry form
function construction_handle_enquiry() {
    check_ajax_referer( 'construction_theme_nonce', 'nonce' );
    $name    = sanitize_text_field( $_POST['name'] ?? '' );
    $email   = sanitize_email( $_POST['email'] ?? '' );
    $phone   = sanitize_text_field( $_POST['phone'] ?? '' );
    $message = sanitize_textarea_field( $_POST['message'] ?? '' );

    if ( empty( $name ) || empty( $email ) || empty( $message ) ) {
        wp_send_json_error( array( 'message' => __( 'Please fill in all required fields.', 'construction-theme' ) ) );
    }

    $to      = get_option( 'admin_email' );
    $subject = sprintf( __( 'New Enquiry from %s', 'construction-theme' ), $name );
    $body    = "Name: $name\nEmail: $email\nPhone: $phone\n\nMessage:\n$message";
    $headers = array( 'Content-Type: text/plain; charset=UTF-8' );

    $sent = wp_mail( $to, $subject, $body, $headers );
    if ( $sent ) {
        wp_send_json_success( array( 'message' => __( 'Your enquiry has been sent successfully.', 'construction-theme' ) ) );
    } else {
        wp_send_json_error( array( 'message' => __( 'There was a problem sending your enquiry. Please try again later.', 'construction-theme' ) ) );
    }
}
add_action( 'wp_ajax_construction_send_enquiry', 'construction_handle_enquiry' );
add_action( 'wp_ajax_nopriv_construction_send_enquiry', 'construction_handle_enquiry' );

// Register Custom Post Type for Testimonials
function construction_register_testimonial_cpt() {
    $labels = array(
        'name'               => _x( 'Testimonials', 'post type general name', 'construction-theme' ),
        'singular_name'      => _x( 'Testimonial', 'post type singular name', 'construction-theme' ),
        'menu_name'          => _x( 'Testimonials', 'admin menu', 'construction-theme' ),
        'name_admin_bar'     => _x( 'Testimonial', 'add new on admin bar', 'construction-theme' ),
        'add_new'            => _x( 'Add New', 'testimonial', 'construction-theme' ),
        'add_new_item'       => __( 'Add New Testimonial', 'construction-theme' ),
        'new_item'           => __( 'New Testimonial', 'construction-theme' ),
        'edit_item'          => __( 'Edit Testimonial', 'construction-theme' ),
        'view_item'          => __( 'View Testimonial', 'construction-theme' ),
        'all_items'          => __( 'All Testimonials', 'construction-theme' ),
        'search_items'       => __( 'Search Testimonials', 'construction-theme' ),
        'not_found'          => __( 'No testimonials found.', 'construction-theme' ),
        'not_found_in_trash' => __( 'No testimonials found in Trash.', 'construction-theme' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => false,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'testimonial' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 21,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    );

    register_post_type( 'testimonial', $args );
}
add_action( 'init', 'construction_register_testimonial_cpt' );

function construction_gallery_shortcode( $atts ) {
    $atts = shortcode_atts(
        array(
            'title'      => __( 'Project Gallery', 'construction-theme' ),
            'limit'      => 12,
            'columns'    => 3,
            'category'   => '',
            'section_id' => 'gallery',
            'demo'       => '0',
        ),
        $atts,
        'construction_gallery'
    );
    $limit      = min( 48, max( 1, absint( $atts['limit'] ) ) );
    $columns    = min( 6, max( 1, absint( $atts['columns'] ) ) );
    $section_id = sanitize_html_class( $atts['section_id'] );
    $query_args = array(
        'post_type'      => 'project',
        'post_status'    => 'publish',
        'posts_per_page' => $limit,
        'meta_query'     => array(
            array(
                'key'     => '_thumbnail_id',
                'compare' => 'EXISTS',
            ),
        ),
    );
    $category = sanitize_title( $atts['category'] );
    if ( $category ) {
        $query_args['tax_query'] = array(
            array(
                'taxonomy' => 'category',
                'field'    => 'slug',
                'terms'    => $category,
            ),
        );
    }
    $projects = new WP_Query( $query_args );

    ob_start();
    $projects_archive_url = get_post_type_archive_link( 'project' );
    ?>
    <section id="<?php echo esc_attr( $section_id ); ?>" class="projects project-gallery">
        <div class="container">
            <?php if ( $atts['title'] ) : ?>
                <h2><?php echo esc_html( $atts['title'] ); ?></h2>
            <?php endif; ?>
            <?php if ( $projects->have_posts() ) : ?>
                <div class="project-grid" style="--gallery-columns: <?php echo esc_attr( $columns ); ?>;">
                    <?php while ( $projects->have_posts() ) : $projects->the_post(); ?>
                        <a class="project-card" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
                            <?php the_post_thumbnail( 'large', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
                            <span class="project-info">
                                <span class="project-info-title"><?php the_title(); ?></span>
                                <span><?php echo esc_html( wp_trim_words( get_the_excerpt(), 15 ) ); ?></span>
                            </span>
                        </a>
                    <?php endwhile; ?>
                </div>
            <?php elseif ( '1' === $atts['demo'] ) : ?>
                <div class="project-grid" style="--gallery-columns: <?php echo esc_attr( $columns ); ?>;">
                    <?php
                    $sample_projects = array(
                        array(
                            'title' => __( 'Sample Family Home', 'construction-theme' ),
                            'image' => 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=900&q=80',
                            'alt'   => __( 'Sample modern family home', 'construction-theme' ),
                        ),
                        array(
                            'title' => __( 'Sample Commercial Space', 'construction-theme' ),
                            'image' => 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=900&q=80',
                            'alt'   => __( 'Sample commercial building', 'construction-theme' ),
                        ),
                        array(
                            'title' => __( 'Sample Interior Renovation', 'construction-theme' ),
                            'image' => 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=80',
                            'alt'   => __( 'Sample renovated interior', 'construction-theme' ),
                        ),
                    );
                    foreach ( array_slice( $sample_projects, 0, $limit ) as $sample_project ) :
                        ?>
                        <article class="project-card">
                            <img src="<?php echo esc_url( $sample_project['image'] ); ?>" alt="<?php echo esc_attr( $sample_project['alt'] ); ?>" loading="lazy" />
                            <span class="project-info">
                                <span class="project-info-title"><?php echo esc_html( $sample_project['title'] ); ?></span>
                            </span>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <p class="project-gallery-empty"><?php esc_html_e( 'Add projects with featured images in WordPress to build your gallery.', 'construction-theme' ); ?></p>
            <?php endif; ?>
            <?php if ( $projects_archive_url ) : ?>
                <div class="project-gallery-actions">
                    <a href="<?php echo esc_url( $projects_archive_url ); ?>" class="button project-gallery-button"><?php esc_html_e( 'View More', 'construction-theme' ); ?></a>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php
    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode( 'construction_gallery', 'construction_gallery_shortcode' );

function construction_map_shortcode( $atts ) {
    $atts = shortcode_atts(
        array(
            'title'   => __( 'Find Us', 'construction-theme' ),
            'address' => '',
            'height'  => 420,
            'zoom'    => 14,
        ),
        $atts,
        'construction_map'
    );
    $address = sanitize_text_field( $atts['address'] );
    if ( '' === $address ) {
        $address = sanitize_text_field( get_theme_mod( 'construction_contact_address', '' ) );
    }

    if ( '' === $address ) {
        $address = 'New York, NY';
    }

    $height = min( 1000, max( 240, absint( $atts['height'] ) ) );
    $zoom   = min( 20, max( 1, absint( $atts['zoom'] ) ) );
    $map_url = add_query_arg(
        array(
            'q'      => $address,
            'z'      => $zoom,
            'output' => 'embed',
        ),
        'https://www.google.com/maps'
    );
    $directions_url = add_query_arg( 'q', $address, 'https://www.google.com/maps/search/' );

    ob_start();
    ?>
    <section id="location" class="construction-map-section">
        <div class="container">
            <?php if ( $atts['title'] ) : ?>
                <h2><?php echo esc_html( $atts['title'] ); ?></h2>
            <?php endif; ?>
            <div class="construction-map-frame">
                <iframe
                    src="<?php echo esc_url( $map_url ); ?>"
                    title="<?php echo esc_attr( sprintf( __( 'Map showing %s', 'construction-theme' ), $address ) ); ?>"
                    width="100%"
                    height="<?php echo esc_attr( $height ); ?>"
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                    allowfullscreen>
                </iframe>
            </div>
            <a class="construction-map-link" href="<?php echo esc_url( $directions_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open map in Google Maps', 'construction-theme' ); ?></a>
        </div>
    </section>
    <?php

    return ob_get_clean();
}
add_shortcode( 'construction_map', 'construction_map_shortcode' );

function construction_testimonials_shortcode( $atts = array() ) {
    $atts = shortcode_atts( array( 'demo' => '0' ), $atts, 'construction_testimonials' );
    $testimonials = new WP_Query( array(
        'post_type'      => 'testimonial',
        'post_status'    => 'publish',
        'posts_per_page' => 5,
    ) );
    $portrait_placeholder = 'data:image/svg+xml,' . rawurlencode(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="40" fill="#f4ecd2"/><circle cx="40" cy="29" r="14" fill="#0a1f44"/><path d="M14 74c2-16 12-25 26-25s24 9 26 25" fill="#0a1f44"/></svg>'
    );

    ob_start();
    ?>
    <section id="testimonials" class="testimonials">
        <div class="container">
            <h2><?php esc_html_e( 'What Our Clients Say', 'construction-theme' ); ?></h2>
            <?php if ( $testimonials->have_posts() ) : ?>
                <div class="testimonial-slider" id="testimonial-slider">
                    <?php
                    $index = 0;
                    while ( $testimonials->have_posts() ) :
                        $testimonials->the_post();
                        ?>
                        <div class="testimonial-item<?php echo 0 === $index ? ' active' : ''; ?>">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <?php the_post_thumbnail( 'thumbnail', array( 'class' => 'testimonial-photo' ) ); ?>
                            <?php else : ?>
                                <img class="testimonial-photo" src="<?php echo esc_attr( $portrait_placeholder ); ?>" alt="<?php esc_attr_e( 'Client portrait placeholder', 'construction-theme' ); ?>" width="64" height="64" />
                            <?php endif; ?>
                            <blockquote class="testimonial-quote"><?php the_content(); ?></blockquote>
                            <p class="testimonial-name">— <?php the_title(); ?></p>
                        </div>
                        <?php
                        $index++;
                    endwhile;
                    ?>
                    <?php if ( $testimonials->post_count > 1 ) : ?>
                        <div class="testimonial-nav">
                            <button type="button" class="prev-testimonial" aria-label="<?php esc_attr_e( 'Previous testimonial', 'construction-theme' ); ?>">&#9664;</button>
                            <button type="button" class="next-testimonial" aria-label="<?php esc_attr_e( 'Next testimonial', 'construction-theme' ); ?>">&#9654;</button>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ( '1' === $atts['demo'] ) : ?>
                <div class="testimonial-slider" id="testimonial-slider">
                    <div class="testimonial-item active">
                        <img class="testimonial-photo" src="<?php echo esc_attr( $portrait_placeholder ); ?>" alt="" width="64" height="64" />
                        <blockquote class="testimonial-quote"><?php esc_html_e( '“Sample client feedback goes here. Replace this text with a genuine review.”', 'construction-theme' ); ?></blockquote>
                        <p class="testimonial-name"><?php esc_html_e( '— Sample Homeowner', 'construction-theme' ); ?></p>
                    </div>
                </div>
            <?php else : ?>
                <p class="testimonial-empty"><?php esc_html_e( 'Add client testimonials in WordPress to display them here.', 'construction-theme' ); ?></p>
            <?php endif; ?>
        </div>
    </section>
    <?php
    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode( 'construction_testimonials', 'construction_testimonials_shortcode' );

// Add About Section Customizer settings
function construction_theme_customizer_about_register( $wp_customize ) {
    $wp_customize->add_section( 'construction_about_section', array(
        'title'    => __( 'About Us', 'construction-theme' ),
        'priority' => 35,
    ) );
    // Image
    $wp_customize->add_setting( 'construction_about_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'construction_about_image_control', array(
        'label'    => __( 'About Image', 'construction-theme' ),
        'section'  => 'construction_about_section',
        'settings' => 'construction_about_image',
    ) ) );
    // Text
    $wp_customize->add_setting( 'construction_about_text', array(
        'default'           => __( 'We are a leading construction company delivering high‑quality projects across residential and commercial sectors.', 'construction-theme' ),
        'sanitize_callback' => 'wp_kses_post',
    ) );
    $wp_customize->add_control( 'construction_about_text_control', array(
        'label'   => __( 'About Text', 'construction-theme' ),
        'section' => 'construction_about_section',
        'settings' => 'construction_about_text',
        'type'    => 'textarea',
    ) );
}
add_action( 'customize_register', 'construction_theme_customizer_about_register' );

// Enqueue Font Awesome for icons
function construction_theme_enqueue_fonts() {
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css', array(), null );
}
add_action( 'wp_enqueue_scripts', 'construction_theme_enqueue_fonts' );
