<?php
/**
 * Front page template – assembles all sections for the homepage
 */
get_header();

if ( have_posts() ) :
    the_post();
    if ( 'builder' === get_post_meta( get_the_ID(), '_elementor_edit_mode', true ) ) :
        ?>
        <main class="elementor-page-content">
            <?php the_content(); ?>
        </main>
        <?php
        get_footer();
        return;
    endif;
    rewind_posts();
endif;
?>

<main class="construction-home">
<?php
/*** Hero Slider ***/
$slides = [];
for ( $i = 1; $i <= 3; $i++ ) {
    $image    = get_theme_mod( "construction_hero_image_$i" );
    $heading  = get_theme_mod( "construction_hero_heading_$i", __( 'Welcome to Our Construction Company', 'construction-theme' ) );
    $subtitle = get_theme_mod( "construction_hero_subtitle_$i", __( 'Building Dreams Into Reality', 'construction-theme' ) );
    if ( $image ) {
        $slides[] = [
            'image'    => esc_url( $image ),
            'heading'  => esc_html( $heading ?: __( 'Welcome to Our Construction Company', 'construction-theme' ) ),
            'subtitle' => esc_html( $subtitle ?: __( 'Building Dreams Into Reality', 'construction-theme' ) ),
        ];
    }
}
if ( empty( $slides ) ) {
    $slides[] = [
        'image'    => 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=2000&q=85',
        'heading'  => esc_html( get_theme_mod( 'construction_hero_heading_1', __( 'Welcome to Our Construction Company', 'construction-theme' ) ) ?: __( 'Welcome to Our Construction Company', 'construction-theme' ) ),
        'subtitle' => esc_html( get_theme_mod( 'construction_hero_subtitle_1', __( 'Building Dreams Into Reality', 'construction-theme' ) ) ?: __( 'Building Dreams Into Reality', 'construction-theme' ) ),
    ];
}
$hero_alignment = get_theme_mod( 'construction_hero_alignment', 'center' );
$hero_height     = get_theme_mod( 'construction_hero_height', 'standard' );
$hero_position   = get_theme_mod( 'construction_hero_image_position', 'center' );
$hero_alignment  = in_array( $hero_alignment, array( 'center', 'left' ), true ) ? $hero_alignment : 'center';
$hero_height     = in_array( $hero_height, array( 'compact', 'standard', 'tall' ), true ) ? $hero_height : 'standard';
$hero_positions  = array( 'center', 'top', 'bottom', 'left center', 'right center' );
$hero_position   = in_array( $hero_position, $hero_positions, true ) ? $hero_position : 'center';
$hero_button_label = get_theme_mod( 'construction_hero_button_label', __( 'Discover More', 'construction-theme' ) );
$hero_button_url   = get_theme_mod( 'construction_hero_button_url', '#about-us' );
if ( is_string( $hero_button_url ) && '' !== trim( $hero_button_url ) ) {
    $hero_button_url = trim( $hero_button_url );
    if ( '#' === $hero_button_url[0] ) {
        $hero_button_url = home_url( '/' . ltrim( $hero_button_url, '/' ) );
    } elseif ( false === wp_http_validate_url( $hero_button_url ) && 0 !== strpos( $hero_button_url, '//' ) ) {
        $hero_button_url = home_url( '/' . ltrim( $hero_button_url, '/' ) );
    }
}
?>
<div class="hero-slider hero-slider-<?php echo esc_attr( $hero_height ); ?>" id="hero-slider">
    <?php foreach ( $slides as $index => $slide ) : ?>
        <div class="hero-slide<?php echo $index === 0 ? ' active' : ''; ?>"<?php if ( $slide['image'] ) : ?> style="background-image: url('<?php echo esc_url( $slide['image'] ); ?>'); background-position: <?php echo esc_attr( $hero_position ); ?>;"<?php endif; ?>>
            <div class="hero-overlay hero-overlay-<?php echo esc_attr( $hero_alignment ); ?>">
                <h1><?php echo $slide['heading']; ?></h1>
                <p><?php echo $slide['subtitle']; ?></p>
                <?php if ( $hero_button_label ) : ?>
                    <a href="<?php echo esc_url( $hero_button_url ); ?>" class="enter-site button"><?php echo esc_html( $hero_button_label ); ?></a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php
/*** About Us ***/
?>
<section id="about-us" class="about-us">
    <div class="container">
        <h2><?php esc_html_e( 'About Us', 'construction-theme' ); ?></h2>
        <div class="about-content">
            <div class="about-image">
                <?php
                // Use a default image if none set.
                $about_img = get_theme_mod( 'construction_about_image' );
                if ( ! $about_img ) {
                    $about_img = 'https://images.unsplash.com/photo-1505842465776-3c9d4a236360?auto=format&fit=crop&w=800&q=80';
                }
                ?>
                <img src="<?php echo esc_url( $about_img ); ?>" alt="<?php esc_attr_e( 'About our company', 'construction-theme' ); ?>" />
            </div>
            <div class="about-text">
                <?php
                $about_text = get_theme_mod( 'construction_about_text', __( 'We are a leading construction company delivering high‑quality projects across residential and commercial sectors.', 'construction-theme' ) );
                ?>
                <?php echo wp_kses_post( wpautop( $about_text ) ); ?>
                <a href="#services" class="button read-more"><?php esc_html_e( 'Our Services', 'construction-theme' ); ?></a>
            </div>
        </div>
    </div>
</section>

<?php
/*** Services ***/
$service_keys = [
    'construction_plan'      => __( 'Construction Plan', 'construction-theme' ),
    'project_execution'      => __( 'Project Execution', 'construction-theme' ),
    'design_surveying'       => __( 'Design Surveying', 'construction-theme' ),
    'interior_design'        => __( 'Interior Design', 'construction-theme' ),
    'landscaping_services'   => __( 'Landscaping Services', 'construction-theme' ),
    'plan_estimation'        => __( 'Plan Estimation', 'construction-theme' ),
];
$service_descriptions = construction_default_service_descriptions();
?>
<section id="services" class="services">
    <div class="container">
        <h2><?php esc_html_e( 'Our Services', 'construction-theme' ); ?></h2>
        <div class="service-cards">
            <?php foreach ( $service_keys as $key => $default_title ) : ?>
                <?php
                $title       = get_theme_mod( "construction_service_title_$key", $default_title );
                $description = get_theme_mod( "construction_service_description_$key", $service_descriptions[ $key ] );
                $icon        = get_theme_mod( "construction_service_icon_$key" );
                ?>
                <div class="service-card">
                    <?php if ( $icon ) : ?>
                        <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
                    <?php endif; ?>
                    <?php if ( $title ) : ?><h3><?php echo esc_html( $title ); ?></h3><?php endif; ?>
                    <p><?php echo esc_html( $description ); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
/*** Statistics ***/
$stat_items = [
    'projects_completed' => __( 'Projects Completed', 'construction-theme' ),
    'happy_customers'   => __( 'Happy Customers', 'construction-theme' ),
    'years_experience'  => __( 'Years in Business', 'construction-theme' ),
];
$sample_stats = array(
    'projects_completed' => 128,
    'happy_customers'    => 96,
    'years_experience'   => 12,
);
?>
<section id="statistics" class="statistics">
    <div class="container">
        <h2><?php esc_html_e( 'Our Numbers', 'construction-theme' ); ?></h2>
        <div class="stats-grid">
            <?php
            foreach ( $stat_items as $key => $label ) :
                $number = get_theme_mod( "construction_stat_number_$key", $sample_stats[ $key ] );
                ?>
                <div class="stat-item">
                    <h3><?php echo esc_html( $number ); ?></h3>
                    <p><?php echo esc_html( $label ); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php echo do_shortcode( '[construction_gallery demo="1"]' ); ?>

<?php
/*** Testimonials ***/
echo do_shortcode( '[construction_testimonials demo="1"]' );
?>

<?php echo do_shortcode( '[construction_map]' ); ?>

<?php
/*** Enquiry Form ***/
$whatsapp_number = trim( (string) get_theme_mod( 'construction_contact_whatsapp', '' ) );
$whatsapp_number = $whatsapp_number ? $whatsapp_number : trim( (string) get_theme_mod( 'construction_contact_phone', '' ) );
$whatsapp_digits = preg_replace( '/[^0-9]/', '', $whatsapp_number );
?>
<section id="enquiry-section" class="enquiry-section">
    <div class="container">
        <h2><?php esc_html_e( 'Get In Touch', 'construction-theme' ); ?></h2>
        <form class="enquiry-form" id="enquiry-form" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" data-whatsapp-number="<?php echo esc_attr( $whatsapp_digits ); ?>">
            <input type="text" name="name" placeholder="<?php esc_attr_e( 'Your Name', 'construction-theme' ); ?>" required />
            <input type="email" name="email" placeholder="<?php esc_attr_e( 'Your Email', 'construction-theme' ); ?>" required />
            <input type="tel" name="phone" placeholder="<?php esc_attr_e( 'Phone (optional)', 'construction-theme' ); ?>" />
            <textarea name="message" rows="4" placeholder="<?php esc_attr_e( 'Your Message', 'construction-theme' ); ?>" required></textarea>
            <input type="hidden" name="action" value="construction_send_enquiry" />
            <input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'construction_theme_nonce' ) ); ?>" />
            <button type="submit"><?php esc_html_e( 'Send Enquiry', 'construction-theme' ); ?></button>
        </form>
        <div id="enquiry-response" class="mt-20"></div>
    </div>
</section>

</main>
<?php get_footer(); ?>
