Construction Theme
===================

## Description
A modern construction-company WordPress theme with a built-in one-page homepage and Elementor support. Use Elementor to build and edit homepage content, or use the built-in homepage and edit its settings through the WordPress Customizer and native post types.

## Theme Files
- `style.css` – theme header & all CSS.
- `functions.php` – theme setup, custom post types (Project, Testimonial), Customizer sections, AJAX enquiry handling, Font Awesome.
- `header.php` / `footer.php` – layout with logo, navigation, mobile toggle, footer widgets.
- `front-page.php` – displays the built-in homepage, or the homepage content created in Elementor.
- `index.php` – fallback for blog/archive pages.
- `page.php` – displays static pages.
- `assets/js/theme.js` – vanilla JS for menu toggle, sliders, AJAX form.
- `README.txt` – this file.

## Installation
1. **Package the theme**: From the `constrution` folder run:
   ```bash
   cd /Users/sachin/Desktop
   zip -r construction-theme.zip constrution -x "*/.DS_Store" ".DS_Store"
   ```
2. **Upload** in WordPress:
   - Dashboard → Appearance → Themes → Add New → **Upload Theme** → choose `construction-theme.zip` → **Install Now** → **Activate**.
3. **Set up the homepage**:
   - Install and activate the free **Elementor Website Builder** plugin if it is not already active.
   - Create a page named *Home*.
   - Settings → Reading → *Your homepage displays* → **A static page** → select the newly created *Home* page.
   - Choose **Edit with Elementor** on the Home page to create and edit its banner, sections, gallery, testimonials, and contact content. The theme keeps its site header and footer around Elementor content.
   - For the built-in banner, go to **Appearance → Customize → Hero Slider** to change slide images, headings, subtitles, button text/link, text alignment, banner height, and image focus. Set the logo under **Appearance → Customize → Site Identity**.
   - If the page has not been edited in Elementor, the theme displays its built-in homepage instead.
4. **Create Menus**:
   - Appearance → Menus → **Primary** menu.
   - If no menu is assigned, the theme displays default links for Home, About, Services, Projects, and Contact. The Services link opens `/services/` as a separate page.
   - The theme creates a published **Services** page at `/services/` automatically if one does not exist. Its built-in responsive page includes construction, design, and interiors services, included work, and the project process. Open **Pages → Services → Edit with Elementor** to customize it; saved Elementor content replaces the built-in layout. Primary-menu links titled **Services** or pointing to `#services` open this separate page.
   - To customize the links, add Custom Links pointing to your homepage sections: `#about-us`, `#services`, `#gallery`, `#testimonials`, `#location`, and `#enquiry-section`. On an Elementor page, set each section's **Advanced → CSS ID** to match its link (without the `#`). Use the full homepage address followed by the anchor if the menu should work from other pages too (for example, `https://example.com/#about-us`).
   - Assign the menu to the **Primary** location.
5. **Add Content**:
   - Build and style sections with Elementor's Container, Heading, Image, Image Gallery, Button, Icon, and Google Maps widgets.
   - For a dynamic project gallery, add a **Shortcode** widget and enter `[construction_gallery]`. Control the gallery with attributes, for example `[construction_gallery title="Our Work" columns="4" limit="12" category="residential"]`. Add Project entries with featured images to manage the photos.
   - For testimonials, add a **Shortcode** widget containing `[construction_testimonials]`.
   - For a map, add a **Shortcode** widget containing `[construction_map address="123 Main Street, City" title="Visit Us" zoom="15" height="500"]`. The address, title, zoom, and height can be changed; if address is omitted, the map uses the address under Appearance → Customize → Contact Details. Until you set an address, a clearly labeled New York demo map is shown.
   - To use the built-in homepage, go to **Appearance → Customize** to set:
     - **Hero Slider** – up to three images, headings, subtitles.
     - **About Us** – image and text.
     - **Services** – titles and icons for the three services.
     - **Statistics** – numbers for projects completed, happy customers, years in business.
     - **Contact Details** – address, phone, email, WhatsApp number.
   - **Projects**: Projects → Add New (choose the **Residential** or **Commercial** category, then add a featured image, title, and excerpt). Featured images are used in the Project Gallery.
   - **Testimonials**: Testimonials → Add New (set the title as the client name, content as the quote, and optionally set a featured image for the client's portrait. A small portrait placeholder is shown until you add one).
6. **Test the site**:
   - Visit the front page and verify hero autoplay, service cards, stats, project grids, testimonial slider, enquiry form, floating contact icons.
   - Resize the browser or use a mobile device to confirm the responsive menu toggle works.

## Editing After Installation
- Set the front page to a static Home page as described above. Edit its sections in Elementor, or use the built-in one-page homepage.
- For the built-in homepage, edit hero slides, About Us, services, statistics, and contact details in Appearance → Customize. A construction banner image is shown by default; upload your own hero images to customize the rotating slides.
- When the built-in homepage has no project or testimonial entries, it shows clearly labeled sample content. Replace it by adding real entries under Projects and Testimonials. Replace the sample service descriptions under Appearance → Customize → Services and sample statistics under Appearance → Customize → Statistics.
- Customize the header links under **Appearance → Menus** and its Enquiry button under **Appearance → Customize → Header & Navigation**. Customize the logo and site title under **Appearance → Customize → Site Identity**. On Elementor-built pages, the page content is edited in Elementor while the theme header remains managed by WordPress menus and Customizer settings.
- Configure the floating Call Now and WhatsApp buttons under **Appearance → Customize → Contact Details**. Enter the business phone with its country code and, optionally, a separate WhatsApp Business Number. Until numbers are configured, the floating buttons remain visible and link to the enquiry form. WhatsApp uses the separate WhatsApp Business Number when provided; otherwise it uses the Phone value.
- Edit projects and testimonials from their respective WordPress dashboard menus. The built-in homepage updates automatically from those entries.
- In Elementor, use `[construction_gallery]`, `[construction_testimonials]`, and `[construction_map]` shortcodes to add dynamic sections anywhere on the page. The Elementor Image Gallery widget can also be used for a manually curated set of images.
- The theme creates a **Services** page at `/services/` if it is missing. Edit it with Elementor to customize the dedicated Services page layout.
- To fine-tune phone and tablet layouts, open a page in Elementor, select the **Responsive Mode** device icons, and adjust each section's width, columns, padding, typography, and visibility for Desktop, Tablet, and Mobile. The theme already switches its navigation and content grids to tablet/mobile layouts automatically.
- The built-in homepage and Services page use gentle scroll-in reveals and hover states. Animations are disabled for visitors who enable reduced motion and do not hide content if JavaScript is unavailable.
- Update the available slide, service, and statistics fields from their corresponding Customizer sections.
- The built-in enquiry form sends an email to the site admin (Settings → General → *Email Address*) and opens WhatsApp with the submitted details when a WhatsApp number or business phone is configured under **Appearance → Customize → Contact Details**.

## Notes
- Elementor requires the separate Elementor Website Builder plugin. The theme's dynamic gallery, testimonials, and address-based map are available through shortcodes in Elementor's Shortcode widget.
- The map embeds a responsive Google Maps view using the supplied address and does not require an API key. The built-in homepage shows a labeled demo map until you replace it with your business address under Appearance → Customize → Contact Details.
- The theme uses native WordPress features for its built-in homepage and does not require React, Vite, Node.js, or paid plugins.
- Font Awesome is loaded from CDN for social icons.
- The theme loads Font Awesome from its CDN, so the site needs an internet connection for those icons.
